package com.practice1;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.context.annotation.Bean;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

public class MainDao {

private JdbcTemplate jdbcTemplate;
private DriverManagerDataSource ds;

public JdbcTemplate getJdbcTemplate() {
	return jdbcTemplate;
}
public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
	this.jdbcTemplate = jdbcTemplate;
}
public int doReg(RegModel rm) {
	// TODO Auto-generated method stub
	String sql = "insert into tb_reg (name,email,password,gender,course,city)values(?,?,?,?,?,?)";
	return jdbcTemplate.update(sql,rm.getName(),rm.getEmail(),rm.getPassword(),rm.getGender(),rm.getCourse(),rm.getCity());
}

public List<RegModel> doLogin(LoginModel lm) {
	// TODO Auto-generated method stub
	String sql = "select * from tb_reg where email='"+lm.getEmail()+"' and password = '"+lm.getPassword()+"'";
	List<RegModel>list = jdbcTemplate.query(sql, new RowMapper<RegModel>()
			{

				@Override
				public RegModel mapRow(ResultSet rs, int arg1) throws SQLException {
					// TODO Auto-generated method stub
					RegModel rm = new RegModel();
					rm.setEmail(rs.getString("email"));
					rm.setPassword(rs.getString("password"));
					return null;
				}
		
			});
	List<RegModel>list1= list.size()>0?list:null;
	return list1;
}
public List<RegModel> getAlldata() {
	// TODO Auto-generated method stub
	
	String sql = "select * from tb_reg";
	List<RegModel>list = jdbcTemplate.query(sql, new RowMapper<RegModel>()
			
			{

				@Override
				public RegModel mapRow(ResultSet rs, int arg1) throws SQLException {
					// TODO Auto-generated method stub
					RegModel rg = new RegModel();
					rg.setId(rs.getInt("id"));
					rg.setName(rs.getString("name"));
					rg.setEmail(rs.getString("email"));
					rg.setPassword(rs.getString("password"));
					rg.setGender(rs.getString("gender"));
					rg.setCourse(rs.getString("course"));
					rg.setCity(rs.getString("city"));
					
					return rg;
				}
		
			});
	return list;
}
public RegModel getEditdata(int id) {
	// TODO Auto-generated method stub
	String sql = "select * from tb_reg where id = ?";
	return jdbcTemplate.queryForObject(sql, new Object[] {id},new BeanPropertyRowMapper<>(RegModel.class));
}
public int getUpdate(RegModel rm) {
	// TODO Auto-generated method stub
	String sql ="update tb_reg set name=? , email=?, password=?, gender=? , course = ?, city =? where id=?";
	return jdbcTemplate.update(sql,rm.getName(),rm.getEmail(),rm.getPassword(),rm.getGender(),rm.getCourse(),rm.getCity(),rm.getId());
}
public int getDelete(int id) {
	// TODO Auto-generated method stub
	String sql = "delete from tb_reg where id='"+id+"'";
	return jdbcTemplate.update(sql);
}

}
