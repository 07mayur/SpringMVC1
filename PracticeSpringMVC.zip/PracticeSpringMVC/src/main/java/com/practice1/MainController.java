package com.practice1;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class MainController {

	@Autowired
	private MainDao dao;
	
	@RequestMapping("/test")
	public String getTest()
	{
		return "test";
	}
	
	@RequestMapping("/register")
	public String getReg()
	{
		return "register";
	}
	
	@RequestMapping("/login")
	public String getLogin()
	{
		return "login";
	}
	
	@RequestMapping(value = "/doReg")
	public String doReg(@ModelAttribute ("rm")RegModel rm)
	{
		dao.doReg(rm);
		return "login";
	}
	
	@RequestMapping(value = "/doLogin")
	public String doLogin(@ModelAttribute("lm") LoginModel lm)
	{
		List<RegModel>list = dao.doLogin(lm);
		if(list!=null)
		{
			System.out.println("login success");
		}
		else
		{
			System.out.println("login failed");
		}
		return "redirect:view";
		
	}
	
	@RequestMapping("view")
	public String getAllData(Model model)
	{
		List<RegModel>list = dao.getAlldata();
		model.addAttribute("list", list);
		return "dashboard";
	}
	
	@RequestMapping(value = "/edit/{id}")
	public String getEditdata(@PathVariable int id,Model model)
	{
		RegModel rg = dao.getEditdata(id);
		model.addAttribute("rm", rg);
		return "editpage";
	}
	
	@RequestMapping(value = "/update",method = RequestMethod.POST)
	public String getUpdate(@ModelAttribute("rm") RegModel rm)
	{
		int i=dao.getUpdate(rm);
		if(i>0)
		{
			System.out.println("updated");
		}
		else
		{
			System.out.println("not updated");
		}
		return "redirect:/view";
	}
	
	@RequestMapping(value = "/delete/{id}")
	public String getDelete(@PathVariable int id,Model model)
	{
	    dao.getDelete(id);
		return "redirect:/view";
	}
}
